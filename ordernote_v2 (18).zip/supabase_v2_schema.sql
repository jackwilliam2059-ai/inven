-- ============================================
-- 발주노트 v2 - Supabase 스키마
-- Payment Manager 프로젝트에 추가 (on_ 접두사)
-- ============================================

-- 1. 매장
CREATE TABLE on_stores (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  password VARCHAR(100),
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. 디자이너
CREATE TABLE on_designers (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  password VARCHAR(100) NOT NULL,
  phone VARCHAR(20),
  kakao_id VARCHAR(100),
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. 공장/시야게
CREATE TABLE on_factories (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  representative VARCHAR(100),
  phone VARCHAR(20),
  memo TEXT,
  type VARCHAR(20) NOT NULL CHECK (type IN ('factory', 'siyage')),
  access_token VARCHAR(100) UNIQUE,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. 관리자
CREATE TABLE on_admins (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL DEFAULT '관리자',
  password VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 기본 관리자 생성
INSERT INTO on_admins (name, password) VALUES ('관리자', '1234');

-- ============================================
-- 사입용 (기존 발주노트 호환)
-- ============================================

-- 5. 사입용 상품
CREATE TABLE on_products (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  code VARCHAR(100),
  supplier VARCHAR(255),
  colors TEXT[] DEFAULT '{}',
  sizes TEXT[] DEFAULT '{}',
  memo TEXT,
  order_unit INTEGER,
  image_url TEXT,
  sort_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. 사입용 발주
CREATE TABLE on_orders (
  id BIGSERIAL PRIMARY KEY,
  product_id BIGINT REFERENCES on_products(id) ON DELETE CASCADE NOT NULL,
  store_id BIGINT REFERENCES on_stores(id) ON DELETE SET NULL,
  order_date DATE DEFAULT CURRENT_DATE,
  color VARCHAR(100),
  size VARCHAR(50) DEFAULT 'FREE',
  quantity INTEGER NOT NULL,
  shipped_quantity INTEGER DEFAULT 0,
  status VARCHAR(50) DEFAULT 'pending',
  note TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- 내수용
-- ============================================

-- 7. 내수용 상품
CREATE TABLE on_domestic_products (
  id BIGSERIAL PRIMARY KEY,
  store_id BIGINT REFERENCES on_stores(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  tags TEXT[] DEFAULT '{}',
  colors TEXT[] DEFAULT '{}',
  sizes TEXT[] DEFAULT '{}',
  designer_id BIGINT REFERENCES on_designers(id) ON DELETE SET NULL,
  factory_id BIGINT REFERENCES on_factories(id) ON DELETE SET NULL,
  siyage_id BIGINT REFERENCES on_factories(id) ON DELETE SET NULL,
  factory_labor_cost INTEGER DEFAULT 0,
  siyage_labor_cost INTEGER DEFAULT 0,
  memo TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. 내수용 발주
CREATE TABLE on_domestic_orders (
  id BIGSERIAL PRIMARY KEY,
  product_id BIGINT REFERENCES on_domestic_products(id) ON DELETE CASCADE NOT NULL,
  store_id BIGINT REFERENCES on_stores(id) ON DELETE SET NULL,
  quantity INTEGER NOT NULL,
  color VARCHAR(100),
  size VARCHAR(50) DEFAULT 'FREE',
  status VARCHAR(50) DEFAULT 'pending_designer',
  -- 상태값:
  -- pending_designer: 디자이너 확인 대기
  -- pending_factory: 공장 확인 대기
  -- in_production: 생산중
  -- shipped: 출고됨 (매장 입고 대기)
  -- received: 입고완료
  -- completed: 결제완료
  expected_ship_date DATE,
  order_date DATE DEFAULT CURRENT_DATE,
  note TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. 출고 기록
CREATE TABLE on_domestic_shipments (
  id BIGSERIAL PRIMARY KEY,
  order_id BIGINT REFERENCES on_domestic_orders(id) ON DELETE CASCADE NOT NULL,
  factory_id BIGINT REFERENCES on_factories(id) ON DELETE SET NULL,
  shipped_quantity INTEGER NOT NULL,
  defect_quantity INTEGER DEFAULT 0,
  shipped_date DATE DEFAULT CURRENT_DATE,
  received_date DATE,
  is_received BOOLEAN DEFAULT FALSE,
  note TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 10. 결제 요청
CREATE TABLE on_payment_requests (
  id BIGSERIAL PRIMARY KEY,
  factory_id BIGINT REFERENCES on_factories(id) ON DELETE SET NULL NOT NULL,
  
  -- 요청 내역
  total_quantity INTEGER NOT NULL,
  labor_cost INTEGER NOT NULL,
  base_amount INTEGER NOT NULL,
  
  -- 차감
  defect_quantity INTEGER DEFAULT 0,
  defect_deduction INTEGER DEFAULT 0,
  extra_deduction INTEGER DEFAULT 0,
  deduction_note TEXT,
  
  -- 최종
  final_amount INTEGER NOT NULL,
  
  -- 상태
  status VARCHAR(50) DEFAULT 'pending_designer',
  -- pending_designer: 디자이너 확인 대기
  -- pending_admin: 관리자 결제 대기
  -- paid: 결제 완료
  
  designer_id BIGINT REFERENCES on_designers(id) ON DELETE SET NULL,
  designer_confirmed_at TIMESTAMPTZ,
  admin_paid_at TIMESTAMPTZ,
  paid_note TEXT,
  
  request_date DATE DEFAULT CURRENT_DATE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 11. 결제요청-출고 연결
CREATE TABLE on_payment_shipments (
  id BIGSERIAL PRIMARY KEY,
  payment_id BIGINT REFERENCES on_payment_requests(id) ON DELETE CASCADE,
  shipment_id BIGINT REFERENCES on_domestic_shipments(id) ON DELETE SET NULL,
  order_id BIGINT REFERENCES on_domestic_orders(id) ON DELETE SET NULL,
  product_name VARCHAR(255),
  quantity INTEGER,
  color VARCHAR(100),
  size VARCHAR(50)
);

-- 12. 알림 로그 (카카오 알림톡용)
CREATE TABLE on_notification_logs (
  id BIGSERIAL PRIMARY KEY,
  type VARCHAR(50) NOT NULL,
  recipient_type VARCHAR(50),
  recipient_id BIGINT,
  recipient_phone VARCHAR(20),
  message TEXT,
  status VARCHAR(20) DEFAULT 'pending',
  sent_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- 인덱스
-- ============================================

CREATE INDEX idx_on_products_active ON on_products(is_active);
CREATE INDEX idx_on_orders_status ON on_orders(status);
CREATE INDEX idx_on_orders_store ON on_orders(store_id);
CREATE INDEX idx_on_orders_date ON on_orders(order_date DESC);

CREATE INDEX idx_on_domestic_products_active ON on_domestic_products(is_active);
CREATE INDEX idx_on_domestic_products_designer ON on_domestic_products(designer_id);
CREATE INDEX idx_on_domestic_products_factory ON on_domestic_products(factory_id);

CREATE INDEX idx_on_domestic_orders_status ON on_domestic_orders(status);
CREATE INDEX idx_on_domestic_orders_product ON on_domestic_orders(product_id);
CREATE INDEX idx_on_domestic_orders_date ON on_domestic_orders(order_date DESC);

CREATE INDEX idx_on_shipments_order ON on_domestic_shipments(order_id);
CREATE INDEX idx_on_shipments_factory ON on_domestic_shipments(factory_id);
CREATE INDEX idx_on_shipments_received ON on_domestic_shipments(is_received);

CREATE INDEX idx_on_payments_factory ON on_payment_requests(factory_id);
CREATE INDEX idx_on_payments_status ON on_payment_requests(status);
CREATE INDEX idx_on_payments_designer ON on_payment_requests(designer_id);

CREATE INDEX idx_on_factories_type ON on_factories(type);
CREATE INDEX idx_on_factories_token ON on_factories(access_token);

-- ============================================
-- RLS (Row Level Security)
-- ============================================

ALTER TABLE on_stores ENABLE ROW LEVEL SECURITY;
ALTER TABLE on_designers ENABLE ROW LEVEL SECURITY;
ALTER TABLE on_factories ENABLE ROW LEVEL SECURITY;
ALTER TABLE on_admins ENABLE ROW LEVEL SECURITY;
ALTER TABLE on_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE on_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE on_domestic_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE on_domestic_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE on_domestic_shipments ENABLE ROW LEVEL SECURITY;
ALTER TABLE on_payment_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE on_payment_shipments ENABLE ROW LEVEL SECURITY;
ALTER TABLE on_notification_logs ENABLE ROW LEVEL SECURITY;

-- 모든 접근 허용 정책 (anon key 사용)
CREATE POLICY "Allow all on_stores" ON on_stores FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on_designers" ON on_designers FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on_factories" ON on_factories FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on_admins" ON on_admins FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on_products" ON on_products FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on_orders" ON on_orders FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on_domestic_products" ON on_domestic_products FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on_domestic_orders" ON on_domestic_orders FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on_domestic_shipments" ON on_domestic_shipments FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on_payment_requests" ON on_payment_requests FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on_payment_shipments" ON on_payment_shipments FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on_notification_logs" ON on_notification_logs FOR ALL USING (true) WITH CHECK (true);

-- ============================================
-- Realtime 활성화
-- ============================================

ALTER PUBLICATION supabase_realtime ADD TABLE on_stores;
ALTER PUBLICATION supabase_realtime ADD TABLE on_designers;
ALTER PUBLICATION supabase_realtime ADD TABLE on_factories;
ALTER PUBLICATION supabase_realtime ADD TABLE on_products;
ALTER PUBLICATION supabase_realtime ADD TABLE on_orders;
ALTER PUBLICATION supabase_realtime ADD TABLE on_domestic_products;
ALTER PUBLICATION supabase_realtime ADD TABLE on_domestic_orders;
ALTER PUBLICATION supabase_realtime ADD TABLE on_domestic_shipments;
ALTER PUBLICATION supabase_realtime ADD TABLE on_payment_requests;

-- ============================================
-- 트리거: updated_at 자동 갱신
-- ============================================

CREATE OR REPLACE FUNCTION on_update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER tr_on_products_updated_at
  BEFORE UPDATE ON on_products
  FOR EACH ROW EXECUTE FUNCTION on_update_updated_at();

CREATE TRIGGER tr_on_orders_updated_at
  BEFORE UPDATE ON on_orders
  FOR EACH ROW EXECUTE FUNCTION on_update_updated_at();

CREATE TRIGGER tr_on_domestic_products_updated_at
  BEFORE UPDATE ON on_domestic_products
  FOR EACH ROW EXECUTE FUNCTION on_update_updated_at();

CREATE TRIGGER tr_on_domestic_orders_updated_at
  BEFORE UPDATE ON on_domestic_orders
  FOR EACH ROW EXECUTE FUNCTION on_update_updated_at();

-- ============================================
-- 완료
-- ============================================

SELECT '발주노트 v2 스키마 생성 완료! (on_ 접두사)' as result;

-- ============================================
-- 기존 DB 마이그레이션 (아래 쿼리 개별 실행)
-- ============================================
-- ALTER TABLE on_domestic_products ADD COLUMN IF NOT EXISTS tags TEXT[] DEFAULT '{}';
-- ALTER TABLE on_domestic_products ADD COLUMN IF NOT EXISTS store_id BIGINT REFERENCES on_stores(id) ON DELETE CASCADE;
-- ALTER TABLE products ADD COLUMN IF NOT EXISTS tags TEXT[] DEFAULT '{}';
